import onnxruntime as ort
import numpy as np

# Load the ONNX model
ort_session = ort.InferenceSession('model.onnx')

# Create a sample input
sample_input = np.array([[5.1, 3.5, 1.4, 0.2]], dtype=np.float32)

# Run inference
outputs = ort_session.run(None, {'float_input': sample_input})

print("Prediction:", outputs)

import http.server
import socketserver
import joblib
import os
import webbrowser
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import json

# Define the port number
PORT = 8000

# Define and train your model
def train_and_save_model():
    data = load_iris()
    X = data.data
    y = data.target
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = RandomForestClassifier()
    model.fit(X_train, y_train)
    joblib.dump(model, 'model.pkl')
    print("Model saved as model.pkl")

# Load the trained model
def load_model():
    if not os.path.exists('model.pkl'):
        train_and_save_model()
    return joblib.load('model.pkl')

model = load_model()

class CustomHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.path = 'htmlfile.html'
        return super().do_GET()

    def do_POST(self):
        if self.path == '/predict':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data)
            
            features = data.get('features')
            if features is None:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b'{"error": "No features provided"}')
                return
            
            try:
                prediction = model.predict([features])
                response = json.dumps({'prediction': prediction.tolist()})
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(response.encode())
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(json.dumps({'error': str(e)}).encode())

# Change the directory to where your HTML file is located
os.chdir(os.path.dirname(os.path.abspath(__file__)))

# Start the server
with socketserver.TCPServer(("", PORT), CustomHTTPRequestHandler) as httpd:
    print(f"Serving at http://localhost:{PORT}")
    
    # Automatically open the HTML file in the default browser
    webbrowser.open(f"http://localhost:{PORT}")
    
    # Keep the server running
    httpd.serve_forever()

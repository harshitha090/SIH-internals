import joblib
from skl2onnx import convert_sklearn
from skl2onnx.common.data_types import FloatTensorType
import onnx

# Load the model
model = joblib.load('model.pkl')

# Define the initial type for the input (here assuming 4 features for Iris dataset)
initial_type = [('float_input', FloatTensorType([None, 4]))]

# Convert the model to ONNX format
onnx_model = convert_sklearn(model, initial_types=initial_type)

# Save the ONNX model
with open('model.onnx', 'wb') as f:
    f.write(onnx_model.SerializeToString())

print("Model successfully converted to ONNX format and saved as model.onnx")

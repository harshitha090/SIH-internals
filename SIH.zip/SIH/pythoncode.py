import http.server
import socketserver
import webbrowser
import os

# Define the port number
PORT = 8000

# Define the handler to serve the HTML file
Handler = http.server.SimpleHTTPRequestHandler

# Change the directory to where your HTML file is located
os.chdir(os.path.dirname(os.path.abspath(__file__)))

# Start the server
with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print(f"Serving at http://localhost:{PORT}")
    
    # Automatically open the HTML file in the default browser
    webbrowser.open(f"file:///C:/Users/Harshitha%20G/Desktop/js-basics/htmlfile.html")
    
    # Keep the server running
    httpd.serve_forever()
